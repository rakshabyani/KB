import lex
from copy import deepcopy
import re

def main():
    file = open("input.txt","r")

    no_of_queries = file.readline().strip()
    queries_list = []
    for i in range(int(no_of_queries)):
        temp = file.readline().replace("\s+","").strip('\n')
        queries_list.append(temp)
    # print(queries_list)

    no_of_sentences_KB = file.readline().strip()
    KB = []
    KB_and_clauses = []
    KB_string = []
    for n in range(int(no_of_sentences_KB)):
        temp = file.readline().replace("\s+", "").strip('\n')
        KB.append(lex.parser.parse(temp))

    # print(KB)
    #Convert to CNF
    for i in range(len(KB)):
        temp = KB[i]
        KB_and_clauses=[]
        #print(any('~' in x for x in temp))
        if '=>' in temp:
            KB[i] = removeimplication(temp)
        result = [element for element in temp if '~' in element]
        if len(result):
            #indices = [i for i, x in enumerate(temp) if x == "~"]
            posnot = temp.index(result[0])
            clause_to_negate = temp[posnot][1]
            if isinstance(clause_to_negate,list):
                negated_clause = negationMethod(clause_to_negate)
                temp[posnot] = negated_clause
                KB[i] = temp
        if '|' in temp:
            pos = temp.index('|')
            result = [element for element in temp if '&' in element]
            temp = convert_to_conjunction_of_clauses(temp[pos - 1], temp[pos + 1])
            KB[i] = temp
        if '&' in temp:
            pos_of_and = temp.index('&')
            clause_before = temp[pos_of_and - 1]
            clause_after = temp[pos_of_and + 1]
            KB_and_clauses.append(seperate_and_clauses(clause_before))
            KB_and_clauses.append(seperate_and_clauses(clause_after))
        else:
            KB_and_clauses.append(temp)
        for element in KB_and_clauses:
            if isinstance(element,list):
                KB_string.append(convert_to_string(element))
            else:
                KB_string.append(temp)
    # print(KB_string)

    predicates = []
    for kbs in KB_string:
        list_of_predicates = []
        if '|' in kbs:
            list_of_predicates = kbs.split('|')
            # list_of_predicates.append(0)
            list_of_predicates = [NOT(x) for x in list_of_predicates]
        else:
            list_of_predicates.append(NOT(kbs))
        predicates.append(list_of_predicates)

    output = open("output.txt","w")

    #Resolve the query
    for query in queries_list:
        indices = []
        query = NOT(query)
        list_of_query_ele = []
        list_of_query_ele.append(query)
        dict_predicates = {}
        dict = {}

        is_resolved = resolve(list_of_query_ele, KB_string, dict, dict_predicates, predicates)

        if is_resolved == "Resolved":
            output.write("TRUE")
        else:
            output.write("FALSE")
        output.write("\n")

    #output.write("TRUE\nTRUE\nTRUE\nFALSE\nFALSE\nTRUE")
    output.close()

    # print(KB)
    # print(KB_string)

#STEP 1 : method to remove implication
def removeimplication(clause):
    temp = []
    implypos = clause.index('=>')
    clause[implypos] = '|'
    clause_to_negate = clause[implypos - 1]
    if isinstance(clause_to_negate,list):
        if '=>' in clause:
            clause[implypos - 1] = removeimplication(clause_to_negate)
    temp.append('~')
    temp.append(clause_to_negate)
    clause[implypos - 1] = temp
    return clause

#STEP 2 : method to move negation inside
def negationMethod(clause_to_negate):
    temp = []
    #if clause_to_negate[0] == '~':
     #   clause_to_negate = clause_to_negate[1]
    if '&' in clause_to_negate:
        #indices = [i for i, x in enumerate(temp) if x == "&"]
        pos_of_and = clause_to_negate.index('&')
        clause_to_negate[pos_of_and] = '|'
        for i in range(len(clause_to_negate)):
            if i != pos_of_and:
                if isinstance(clause_to_negate[i],list):
                    #copy_of_clause = deepcopy(clause_to_negate[i])
                    clause_to_negate[i] = negationMethod(clause_to_negate[i])
                else:
                    temp = []
                    temp.append('~')
                    temp.append(clause_to_negate[i])
                    clause_to_negate[i] = temp

    elif '|' in clause_to_negate:
        pos_of_or = clause_to_negate.index('|')
        clause_to_negate[pos_of_or] = '&'
        for i in range(len(clause_to_negate)):
            if i != pos_of_or:
                if isinstance(clause_to_negate[i],list):
                    clause_to_negate[i] = negationMethod(clause_to_negate[i])
                temp = []
                temp.append('~')
                temp.append(clause_to_negate[i])
                clause_to_negate[i] = temp
    elif '~' in clause_to_negate:
        clause_to_negate.pop(0)
    return clause_to_negate

#STEP 3 : Convert to conjunction of disjunction clauses
def convert_to_conjunction_of_clauses(clause_before, clause_after):
    #indices = [i for i, x in enumerate(clause) if x == "|"]
    #for index in indices:
    cnf_clause = []
    constructed_clause = []
    if isinstance(clause_before, list):
        temp = clause_before
        if '|' in temp:
            pos = temp.index('|')
            temp = convert_to_conjunction_of_clauses(temp[pos-1], temp[pos+1])
        if '&' in temp:
            pos_of_and = temp.index('&')
            constructed_clause.append(temp[pos_of_and-1])
            constructed_clause.append('|')
            constructed_clause.append(clause_after)
            cnf_clause.append(constructed_clause)
            constructed_clause = []
            constructed_clause.append(temp[pos_of_and+1])
            constructed_clause.append('|')
            constructed_clause.append(clause_after)
            cnf_clause.append('&')
            cnf_clause.append(constructed_clause)
    if len(cnf_clause) == 0:
        cnf_clause.append(clause_before)
        cnf_clause.append('|')
        cnf_clause.append(clause_after)
    return cnf_clause

#STEP 4 : Remove the parantheses and make it a list of clauses
def seperate_and_clauses(clause):
    KB_and_clauses = []
    if '&' in clause:
        pos_of_and = clause.index('&')
        clause_before = clause[pos_of_and - 1]
        clause_after = clause[pos_of_and + 1]
        and_before = [element for element in clause_before if '&' in element]
        and_after = [element for element in clause_after if '&' in element]
        if len(and_before) > 0 :
            KB_and_clauses.append(convert_to_string(clause_before))
        if len(and_after) > 0 :
            KB_and_clauses.append(convert_to_string(clause_after))
    else:
        KB_and_clauses.append(clause)
    return KB_and_clauses

def convert_to_string(clause):
    KB_string = ''
    for element in clause:
        if isinstance(element,list):
            KB_string+=convert_to_string(element)
        else:
            KB_string += element
    return KB_string

def resolve(list_of_query_ele, KB_string, dict,dict_predicates, predicates):
    is_resolved = False
    list_of_predicates = []
    indices = []
    index_of_query = 0
    while (len(list_of_query_ele) != 0) and (index_of_query < len(list_of_query_ele)):
        query = list_of_query_ele[index_of_query]
        index_of_query += 1
        # check_in_KB(query)
        predicate_q = get_query_predicate(query)
        indices = []
        for i in range(len(predicates)):
            ele = ''
            element = predicates[i]
            for elem in element:
                if (elem.find(predicate_q) != -1) :
                    for elem in element:
                        ele += NOT(elem) + '|'
                    ele = ele[:-1]
                    indices.append(ele)

        # list_of_query = deepcopy(list_of_query_ele)
        # matching_clauses = check_in_KB(query, KB_string, dict_predicates, dict)
        for index_clause in indices:
            dict_copy = {}
            dict_predicates_copy = deepcopy(dict_predicates)
            list_of_query = deepcopy(list_of_query_ele)
            is_resolved = False
            is_unified = check_in_KB(query,KB_string, dict_predicates_copy, list_of_query, dict_copy, index_clause)
            if is_unified == "Resolved":
                return "Resolved"
            if is_unified == "False" and len(list_of_query) == 1:
                continue
            elif is_unified == "False":
                continue
            if is_unified == "True" and len(list_of_query) == 0:
                return True
            is_resolved = resolve(list_of_query, KB_string, dict_copy, dict_predicates_copy, predicates)
            if is_resolved == "Resolved":
                return "Resolved"

    # if is_resolved == "True":
    #     return "True"
    # else:
    return "False"

def check_in_KB(query, KB_string, dict_predicates,list_of_query_ele, dict, matching_clause):

    if dict_predicates.get(matching_clause) != 1:
        dict_predicates[matching_clause] = 0

        predicate_q = ''
        i = 0
        while (query[i] != '('):
            predicate_q += query[i]
            i += 1
        i = i + 1
        vars_q = query[i:len(query) - 1]

        list_of_predicates = []
        if '|' in matching_clause:
            list_of_predicates = matching_clause.split('|')
            list_of_predicates = [NOT(x) for x in list_of_predicates]
        else:
            list_of_predicates.append(NOT(matching_clause))

        unified = False
        for predicate in list_of_predicates:
            predicate_s = ''
            i = 0
            while (predicate[i] != '('):
                predicate_s += predicate[i]
                i += 1
            i = i + 1
            vars_s = predicate[i:len(predicate) - 1]
            query_variables = vars_q.split(',')
            sentence_variables = vars_s.split(',')
            if (predicate_q == predicate_s):
                if len(query_variables) == len(sentence_variables):
                    unified = unify(vars_q, vars_s,dict)
            if unified:
                dict_predicates[matching_clause] = 1
                list_of_predicates.remove(predicate)
                temp_list = []
                for temp in list_of_predicates:
                    for key in dict.keys():
                        temp = temp.replace(key,dict.get(key))
                    temp_list.append(NOT(temp))
                list_of_query_ele.remove(query)
                for temp in list_of_query_ele:
                    for key in dict.keys():
                        temp.replace(key,dict.get(key))
                list_of_query_ele.extend(temp_list)
                if len(list_of_query_ele) == 0:
                    return "Resolved"
                return "True"
    return "False"

def unify(vars_q, vars_s,dict):
    no_of_vars_unified = 0
    query_variables = vars_q.split(',')
    sentence_variables = vars_s.split(',')
    if len(query_variables) != len(sentence_variables):
        return False
    for index in range(len(query_variables)):
        variable_q = query_variables[index]
        variable_s = sentence_variables[index]

        #F(x) and F(Tim)
        if (isVar(variable_q)) and (not isVar(variable_s)):
            if variable_q in dict:
                if dict[variable_q] == variable_s:
                    no_of_vars_unified += 1

            else:
                if not (variable_s in dict.values()):
                    dict[variable_q] = variable_s
                    no_of_vars_unified += 1

        #F(Jack) and F(y)
        elif (not isVar(variable_q)) and (isVar(variable_s)):
            if variable_s in dict:
                if dict[variable_s] == variable_q:
                    no_of_vars_unified += 1

            else:
                if not variable_q in dict.values():
                    dict[variable_s] = variable_q
                    no_of_vars_unified += 1

        #F(x) nd F(y)
        elif (isVar(variable_q)) and (isVar(variable_s)):
            if (variable_q in dict) and (not variable_s in dict):
                dict[variable_s] = dict.get(variable_q)
                no_of_vars_unified += 1
            elif (not variable_q in dict) and (variable_s in dict):
                dict[variable_q] = dict.get(variable_s)
                no_of_vars_unified += 1
            else:
                no_of_vars_unified += 1

        #F(Jack) and F(Jack)
        elif (not isVar(variable_q)) and (not isVar(variable_s)):
            if variable_q == variable_s:
                no_of_vars_unified += 1
    if no_of_vars_unified == len(query_variables):
        return True
    else:
        return False


def isVar(elem):
    return True if re.search("^[a-z]",elem) else False


def NOT(clause):
    if clause[0] == '~':
        clause = clause.lstrip('~')
    else:
        clause = '~' + clause
    return clause

def get_query_predicate(query):
    predicate_q = ''
    i = 0
    while(query[i] != '('):
        predicate_q += query[i]
        i += 1
    predicate_q += '('
    return predicate_q
main()