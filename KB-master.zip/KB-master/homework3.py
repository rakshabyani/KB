import lex
from copy import deepcopy
import re

def main():
    file = open("input.txt","r")

    no_of_queries = file.readline().strip()
    queries_list = []
    for i in range(int(no_of_queries)):
        temp = file.readline().replace("\s+","").strip('\n')
        queries_list.append(temp)
    print(queries_list)

    no_of_sentences_KB = file.readline().strip()
    KB = []
    KB_and_clauses = []
    KB_string = []
    for n in range(int(no_of_sentences_KB)):
        temp = file.readline().replace("\s+", "").strip('\n')
        KB.append(lex.parser.parse(temp))

    print(KB)
    #Convert to CNF
    for i in range(len(KB)):
        temp = KB[i]
        KB_and_clauses=[]
        #print(any('~' in x for x in temp))
        if '=>' in temp:
            KB[i] = removeimplication(temp)
        result = [element for element in temp if '~' in element]
        if len(result):
            #indices = [i for i, x in enumerate(temp) if x == "~"]
            posnot = temp.index(result[0])
            clause_to_negate = temp[posnot][1]
            if isinstance(clause_to_negate,list):
                negated_clause = negationMethod(clause_to_negate)
                temp[posnot] = negated_clause
                KB[i] = temp
        if '|' in temp:
            pos = temp.index('|')
            result = [element for element in temp if '&' in element]
            temp = convert_to_conjunction_of_clauses(temp[pos - 1], temp[pos + 1])
            KB[i] = temp
        if '&' in temp:
            pos_of_and = temp.index('&')
            clause_before = temp[pos_of_and - 1]
            clause_after = temp[pos_of_and + 1]
            KB_and_clauses.append(seperate_and_clauses(clause_before))
            KB_and_clauses.append(seperate_and_clauses(clause_after))
        else:
            KB_and_clauses.append(temp)
        for element in KB_and_clauses:
            if isinstance(element,list):
                KB_string.append(convert_to_string(element))
            else:
                KB_string.append(temp)

    dict = {}
    #Resolve the query
    for query in queries_list:
        print(resolve(NOT(query),KB_string,dict))
    print(KB)
    print(KB_string)
    output = open("output.txt","w")



#STEP 1 : method to remove implication
def removeimplication(clause):
    temp = []
    implypos = clause.index('=>')
    clause[implypos] = '|'
    clause_to_negate = clause[implypos - 1]
    if isinstance(clause_to_negate,list):
        if '=>' in clause:
            clause[implypos - 1] = removeimplication(clause_to_negate)
    temp.append('~')
    temp.append(clause_to_negate)
    clause[implypos - 1] = temp
    return clause

#STEP 2 : method to move negation inside
def negationMethod(clause_to_negate):
    temp = []
    #if clause_to_negate[0] == '~':
     #   clause_to_negate = clause_to_negate[1]
    if '&' in clause_to_negate:
        #indices = [i for i, x in enumerate(temp) if x == "&"]
        pos_of_and = clause_to_negate.index('&')
        clause_to_negate[pos_of_and] = '|'
        for i in range(len(clause_to_negate)):
            if i != pos_of_and:
                if isinstance(clause_to_negate[i],list):
                    #copy_of_clause = deepcopy(clause_to_negate[i])
                    clause_to_negate[i] = negationMethod(clause_to_negate[i])
                else:
                    temp = []
                    temp.append('~')
                    temp.append(clause_to_negate[i])
                    clause_to_negate[i] = temp

    elif '|' in clause_to_negate:
        pos_of_or = clause_to_negate.index('|')
        clause_to_negate[pos_of_or] = '&'
        for i in range(len(clause_to_negate)):
            if i != pos_of_or:
                if isinstance(clause_to_negate[i],list):
                    clause_to_negate[i] = negationMethod(clause_to_negate[i])
                temp = []
                temp.append('~')
                temp.append(clause_to_negate[i])
                clause_to_negate[i] = temp
    elif '~' in clause_to_negate:
        clause_to_negate.pop(0)
    return clause_to_negate

#STEP 3 : Convert to conjunction of disjunction clauses
def convert_to_conjunction_of_clauses(clause_before, clause_after):
    #indices = [i for i, x in enumerate(clause) if x == "|"]
    #for index in indices:
    cnf_clause = []
    constructed_clause = []
    if isinstance(clause_before, list):
        temp = clause_before
        if '|' in temp:
            pos = temp.index('|')
            temp = convert_to_conjunction_of_clauses(temp[pos-1], temp[pos+1])
        if '&' in temp:
            pos_of_and = temp.index('&')
            constructed_clause.append(temp[pos_of_and-1])
            constructed_clause.append('|')
            constructed_clause.append(clause_after)
            cnf_clause.append(constructed_clause)
            constructed_clause = []
            constructed_clause.append(temp[pos_of_and+1])
            constructed_clause.append('|')
            constructed_clause.append(clause_after)
            cnf_clause.append('&')
            cnf_clause.append(constructed_clause)
    if len(cnf_clause) == 0:
        cnf_clause.append(clause_before)
        cnf_clause.append('|')
        cnf_clause.append(clause_after)
    return cnf_clause

#STEP 4 : Remove the parantheses and make it a list of clauses
def seperate_and_clauses(clause):
    KB_and_clauses = []
    if '&' in clause:
        pos_of_and = clause.index('&')
        clause_before = clause[pos_of_and - 1]
        clause_after = clause[pos_of_and + 1]
        and_before = [element for element in clause_before if '&' in element]
        and_after = [element for element in clause_after if '&' in element]
        if len(and_before) > 0 :
            KB_and_clauses.append(convert_to_string(clause_before))
        if len(and_after) > 0 :
            KB_and_clauses.append(convert_to_string(clause_after))
    else:
        KB_and_clauses.append(clause)
    return KB_and_clauses

def convert_to_string(clause):
    KB_string = ''
    for element in clause:
        if isinstance(element,list):
            KB_string+=convert_to_string(element)
        else:
            KB_string += element
    return KB_string

def resolve(query_to_resolve, KB_string, dict):
    list_of_predicates = []
    list_of_query_ele = []
    dict_predicates = {}
    resolved = False
    if query_to_resolve == '':
        return True
    if '|' in query_to_resolve:
        list_of_query_ele = query_to_resolve.split('|')
    else:
        list_of_query_ele.append(query_to_resolve)

    resolved = check_in_KB(KB_string, dict_predicates, list_of_query_ele, resolved)

    if resolved == False:
        if [dict.get(a) for a in dict.keys()] == 0:
            exhausted = False
            resolved = check_in_KB(KB_string, dict_predicates, list_of_query_ele, resolved)

    return resolved

def check_in_KB(KB_string, dict_predicates, list_of_query_ele, resolved):
    for query in list_of_query_ele:
        if query == '':
            return True
        resolved = False
        predicate_q = ''
        i = 0
        while (query[i] != '('):
            predicate_q += query[i]
            i += 1
        i = i + 1
        vars_q = query[i:len(query) - 1]
        for str in KB_string:
            if dict_predicates.get(str) != 1:
                dict_predicates[str] = 0
                list_of_predicates = []
                if '|' in str:
                    list_of_predicates = str.split('|')
                    #list_of_predicates.append(0)
                    list_of_predicates = [NOT(x) for x in list_of_predicates]
                else:
                    list_of_predicates.append(NOT(str))
                if query in list_of_predicates:
                    dict_predicates[str] = 1
                    list_of_predicates.remove(query)
                    query = ''
                    for x in list_of_predicates:
                        query+= NOT(x) + '|'
                    query = query[:-1]
                    resolved = resolve(query, KB_string,dict)
                    if resolved:
                        break
                else:
                    for predicate in list_of_predicates:
                        predicate_s = ''
                        i = 0
                        while (predicate[i] != '('):
                            predicate_s += predicate[i]
                            i += 1
                        i = i + 1
                        vars_s = predicate[i:len(predicate) - 1]
                        if (predicate_q == NOT(predicate_s)):
                            resolved = unify(vars_q, vars_s,dict)
                            if resolved:
                                dict_predicates[str] = 1
                                list_of_predicates.remove(predicate)
                                query = ''
                                for x in list_of_predicates:
                                    query += NOT(x) + '|'
                                query = query[:-1]
                                resolved = resolve(query, KB_string,dict)
                                break
    return resolved

def unify(vars_q, vars_s,dict):
    no_of_vars_unified = 0
    query_variables = vars_q.split(',')
    sentence_variables = vars_s.split(',')
    if len(query_variables) != len(sentence_variables):
        return False
    for index in range(len(query_variables)):
        variable_q = query_variables[index]
        variable_s = sentence_variables[index]

        #F(x) and F(Tim)
        if (isVar(variable_q)) and (not isVar(variable_s)):
            if variable_q in dict:
                if dict[variable_q] == variable_s:
                    no_of_vars_unified += 1
                    # break
            else:
                dict[variable_q] = variable_s
                no_of_vars_unified += 1
                # break
        #F(Jack) and F(y)
        elif (not isVar(variable_q)) and (isVar(variable_s)):
            if dict.get(variable_s) == variable_q:
                no_of_vars_unified += 1
                # break
            else:
                dict[variable_s] = variable_q
                no_of_vars_unified += 1
                # break
        #F(x) nd F(y)
        elif (isVar(variable_q)) and (isVar(variable_s)):
            if (variable_q in dict) and (not variable_s in dict):
                #dict.get(variable_s) != None
                dict[variable_s] = dict.get(variable_q)
                no_of_vars_unified += 1
            elif (not variable_q in dict) and (variable_s in dict):
                dict[variable_q] = dict.get(variable_s)
                no_of_vars_unified += 1
            elif (variable_q in dict) and (variable_s in dict):
                if dict.get(variable_q) == dict.get(variable_s):
                    no_of_vars_unified += 1
            elif variable_q == variable_s:
                no_of_vars_unified += 1
                    # break
        #F(Jack) and F(Jack)
        elif (not isVar(variable_q)) and (not isVar(variable_s)):
            if variable_q == variable_s:
                no_of_vars_unified += 1
                # break
    if no_of_vars_unified == len(query_variables):
        return True
    else:
        return False


def isVar(str):
    return True if re.search("^[a-z]",str) else False


def NOT(clause):
    if clause[0] == '~':
        clause = clause.lstrip('~')
    else:
        clause = '~' + clause
    return clause
main()